package br.com.curso.ado.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_alunos")
public class Alunos {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long ra;
	private String name;
	private String cep;
	private int numero;
	private String complemento;
	private double notaAdo1;
	private double notaPI;
	
	public Alunos() {
        // Construtor padrão sem argumentos
    }

    public Alunos(long ra, String name, String cep, int numero, String complemento, double notaAdo1, double notaPI) {
        super();
        this.ra = ra;
        this.name = name;
        this.cep = cep;
        this.numero = numero;
        this.complemento = complemento;
        this.notaAdo1 = notaAdo1;
        this.notaPI = notaPI;
    }

	public long getRa() {
		return ra;
	}

	public void setRa(long ra) {
		this.ra = ra;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public double getNotaAdo1() {
		return notaAdo1;
	}

	public void setNotaAdo1(double notaAdo1) {
		this.notaAdo1 = notaAdo1;
	}

	public double getNotaPI() {
		return notaPI;
	}

	public void setNotaPI(double notaPI) {
		this.notaPI = notaPI;
	}

}
