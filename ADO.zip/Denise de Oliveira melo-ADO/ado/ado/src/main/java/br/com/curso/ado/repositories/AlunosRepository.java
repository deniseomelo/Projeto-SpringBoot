package br.com.curso.ado.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.curso.ado.entities.Alunos;

public interface AlunosRepository extends JpaRepository<Alunos,Long>{

	
   
}
