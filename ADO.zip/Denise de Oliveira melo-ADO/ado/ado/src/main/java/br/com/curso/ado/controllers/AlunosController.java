package br.com.curso.ado.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.curso.ado.entities.Alunos;
import br.com.curso.ado.repositories.AlunosRepository;

@RestController
@RequestMapping(value = "/alunos")
public class AlunosController {
	
	@Autowired
	private AlunosRepository repository;
	
	@GetMapping
	public List<Alunos> findAll(){
		List<Alunos> result = repository.findAll();
		return result;
	}
	@GetMapping(value = "/{ra}")
	public Alunos  findById(@PathVariable Long ra){
		Alunos result = repository.findById(ra).get();
		return result ;
	}
	@PostMapping
	public Alunos insert(@RequestBody Alunos alunos){
		Alunos result = repository.save(alunos);

		return result ;
	}
	@DeleteMapping("/{ra}")
	public void deletar(@PathVariable Long ra) {
	    repository.deleteById(ra);
	}
	@PutMapping(value = "/{ra}")
	public ResponseEntity<Alunos> update(@PathVariable Long ra, @RequestBody Alunos aluno) {
	    Alunos existingAluno = findById(ra);

	    if (existingAluno != null) {
	        // Update the existing student's name with the new name from the 'aluno' object
	        existingAluno.setName(aluno.getName());

	        // Save the updated student in the repository
	        Alunos updatedAluno = repository.save(existingAluno);

	        return ResponseEntity.ok(updatedAluno); // Return a success response with the updated student
	    } else {
	        return ResponseEntity.notFound().build(); // Return a 404 Not Found response if the student doesn't exist
	    }
	}


}
