
INSERT INTO tb_alunos(ra, name, cep, numero, complemento, nota_Ado1, notaPI) VALUES (1, 'Denise Melo', '05524-00', 424, 'casa', 3.0, 7.0);
INSERT INTO tb_alunos(ra, name, cep, numero, complemento, nota_Ado1, notaPI) VALUES (2, 'Bruno Oliveira', '05524-000', 758, 'comercial', 2.0, 6.0);
INSERT INTO tb_alunos(ra, name, cep, numero, complemento, nota_Ado1, notaPI) VALUES (3, 'Maria Helena', '02269-000', 589, 'apartamento', 1.0, 4.0);
INSERT INTO tb_alunos(ra, name, cep, numero, complemento, nota_Ado1, notaPI) VALUES (4, 'Diego Carvalho', '064260-000', 123, 'casa', 2.0, 5.0);
INSERT INTO tb_alunos(ra, name, cep, numero, complemento, nota_Ado1, notaPI) VALUES (5, 'Rita de Cassia', '05521-100', 190, 'comercial', 3.0, 3.0);

