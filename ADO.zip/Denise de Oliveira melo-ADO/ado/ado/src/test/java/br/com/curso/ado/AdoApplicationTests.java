package br.com.curso.ado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdoApplicationTests {

	@Test
	void contextLoads() {
	}

}
